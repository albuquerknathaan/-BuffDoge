// ══════════════════════════════════════════════════════════════════
//  IRON LABS — API de Vendas (Vercel Serverless)
//  GET  /api/vendas        → lista todas
//  POST /api/vendas        → cria nova
//  PUT  /api/vendas        → atualiza status
//  DELETE /api/vendas?id=  → exclui
// ══════════════════════════════════════════════════════════════════
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
)

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization')
  if (req.method === 'OPTIONS') return res.status(200).end()

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('vendas')
        .select('*')
        .order('created_at', { ascending: false })
      if (error) throw error
      return res.json(data)
    }

    if (req.method === 'POST') {
      const venda = req.body
      const { data, error } = await supabase
        .from('vendas')
        .insert([{ ...venda, created_at: new Date().toISOString() }])
        .select()
      if (error) throw error

      // Atualiza cliente
      await supabase.rpc('upsert_cliente', {
        p_nome: venda.cliente,
        p_telefone: venda.telefone || '',
        p_lucro: venda.lucro || 0,
        p_receita: venda.valor_total || 0,
        p_data: venda.data
      }).catch(() => {})

      return res.status(201).json(data[0])
    }

    if (req.method === 'PUT') {
      const { id, ...updates } = req.body
      const { error } = await supabase
        .from('vendas')
        .update(updates)
        .eq('id', id)
      if (error) throw error
      return res.json({ ok: true })
    }

    if (req.method === 'DELETE') {
      const { id } = req.query
      const { error } = await supabase
        .from('vendas')
        .delete()
        .eq('id', id)
      if (error) throw error
      return res.json({ ok: true })
    }

    return res.status(405).json({ error: 'Method not allowed' })
  } catch (error) {
    console.error('Vendas API error:', error)
    return res.status(500).json({ error: error.message })
  }
}
