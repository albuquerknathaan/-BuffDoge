// ══════════════════════════════════════════════════════════════════
//  IRON LABS — Agente CDO (Vercel Serverless Function)
//  Deploy: /api/cdo
//  Chamado pelo frontend quando: nova venda, pedido de análise,
//  relatório semanal agendado
// ══════════════════════════════════════════════════════════════════

const ANTHROPIC_API = 'https://api.anthropic.com/v1/messages'

// Sistema de identidade do agente CDO
const CDO_IDENTITY = `Você é o CDO (Chief Data Officer) da Iron Labs Pharmaceutical.
Seu papel: inteligência de negócios em tempo real, governança de dados, 
estratégia de crescimento e alertas proativos.

Catálogo de produtos:
TS-E/TS-C/TS-P (Testosteronas) | SUS (Sustanon) | DC-N/NPP (Nandrolonas)
TB-A (Trembolona) | MS-P (Masteron) | BD-U (Boldenona) | OXA (Oxandrolona)
DBL (Dianabol) | CLEN (Clembuterol) | HMG (Hemogenin) | COSM (Cosméticos)
TG (T.G — especial) | PROV (Proviron) | STAN (Stanozolol)
Peptídios: GHK-CU | TB500 | HGHFRAG | AOD | SS31 | MOTSC | KPV | BPC157 | BPC+TB

Precificação:
- Padrão: <500un=R$110 | 500un=R$70 | 1000un=R$65 | 1500+un=R$60 | custo=R$31,07
- TG: venda=R$900 | custo=R$537,50 (FIXO independente de volume)
- GHK-CU: venda=R$600 | custo=R$200 | KPV: venda=R$500 | custo=R$200
- Demais peptídios: venda=R$400 | custo=R$200 | BPC+TB: venda=R$450 | custo=R$400

Sempre responda em português. Seja direto, analítico, orientado a ação.`

// Modos do agente
const MODOS = {
  // Análise após nova venda
  nova_venda: (venda, historico) => `
${CDO_IDENTITY}

MODO: Análise de nova venda

VENDA REGISTRADA AGORA:
Cliente: ${venda.cliente}
Produto: ${venda.produto}  
Qtd: ${venda.qtd} unidades
Pagamento: ${venda.pagamento}
Valor: R$${venda.valor_total}

HISTÓRICO DO CLIENTE (${historico.length} compras anteriores):
${historico.map(v => `${v.data}: ${v.produto} x${v.qtd}`).join('\n') || 'Primeira compra'}

Forneça em 3-5 linhas:
1. Classificação do cliente (VIP/Potencial/Regular/Novo)
2. Uma ação comercial concreta para maximizar o valor deste cliente
3. Alerta se houver algum padrão importante

Seja ultra direto. Máximo 100 palavras.`,

  // Diagnóstico completo
  diagnostico: (dados) => `
${CDO_IDENTITY}

MODO: Diagnóstico Executivo Completo

DADOS DA OPERAÇÃO:
Período analisado: ${dados.periodo}
Total vendas: ${dados.total_vendas}
Receita: R$${dados.receita}
Lucro: R$${dados.lucro}
Margem: ${dados.margem}%
Clientes únicos: ${dados.n_clientes}

TOP CLIENTES:
${dados.top_clientes}

PRODUTOS MAIS VENDIDOS:
${dados.top_produtos}

VENDAS DETALHADAS:
${dados.vendas_detalhe}

Entregue relatório executivo com:
1. SCORE DA EMPRESA (0-100) com justificativa
2. STATUS FINANCEIRO — tendência e benchmark
3. TOP CLIENTES — segmentação VIP/Potencial/Risco
4. PRODUTOS — estrelas vs fracos
5. ALERTAS CRÍTICOS — riscos e oportunidades urgentes
6. PLANO DE AÇÃO — 3 movimentos concretos nos próximos 30 dias
7. PROJEÇÃO — receita e lucro esperados no próximo mês`,

  // Relatório semanal
  relatorio_semanal: (dados) => `
${CDO_IDENTITY}

MODO: Relatório Semanal Executivo

SEMANA: ${dados.semana}
Vendas: ${dados.vendas} | Receita: R$${dados.receita} | Lucro: R$${dados.lucro}
Variação vs semana anterior: ${dados.variacao}%

Clientes que compraram: ${dados.clientes_semana}
Novos clientes: ${dados.novos_clientes}

Forneça resumo semanal executivo com:
- Performance vs semana anterior
- Destaque positivo e alerta da semana
- Uma ação prioritária para a próxima semana

Máximo 150 palavras. Tom de briefing executivo.`,

  // Pergunta livre
  pergunta: (pergunta, contexto) => `
${CDO_IDENTITY}

CONTEXTO DA EMPRESA:
${contexto}

PERGUNTA DO EXECUTIVO:
${pergunta}

Responda de forma direta e baseada nos dados fornecidos.`
}

// Handler principal (Vercel Serverless)
export default async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
  
  if (req.method === 'OPTIONS') return res.status(200).end()
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })

  const { modo, dados } = req.body

  if (!modo || !dados) {
    return res.status(400).json({ error: 'modo e dados são obrigatórios' })
  }

  // Monta o prompt baseado no modo
  let prompt
  switch (modo) {
    case 'nova_venda':
      prompt = MODOS.nova_venda(dados.venda, dados.historico || [])
      break
    case 'diagnostico':
      prompt = MODOS.diagnostico(dados)
      break
    case 'relatorio_semanal':
      prompt = MODOS.relatorio_semanal(dados)
      break
    case 'pergunta':
      prompt = MODOS.pergunta(dados.pergunta, dados.contexto || '')
      break
    default:
      return res.status(400).json({ error: `Modo desconhecido: ${modo}` })
  }

  try {
    const response = await fetch(ANTHROPIC_API, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      })
    })

    if (!response.ok) {
      const err = await response.text()
      throw new Error(`Anthropic API error ${response.status}: ${err}`)
    }

    const data = await response.json()
    const texto = data.content?.map(b => b.text || '').join('\n') || ''

    // Salva o insight no Supabase (opcional)
    if (process.env.SUPABASE_SERVICE_KEY) {
      await fetch(`${process.env.SUPABASE_URL}/rest/v1/insights`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': process.env.SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${process.env.SUPABASE_SERVICE_KEY}`
        },
        body: JSON.stringify({
          modo,
          input: JSON.stringify(dados).slice(0, 500),
          output: texto.slice(0, 2000),
          created_at: new Date().toISOString()
        })
      }).catch(() => {}) // não falha se log falhar
    }

    return res.status(200).json({ texto, modo, timestamp: new Date().toISOString() })

  } catch (error) {
    console.error('CDO Agent error:', error)
    return res.status(500).json({ error: error.message })
  }
}
