# 🚀 Guia de Deploy — Iron Labs Cloud
## Tempo estimado: 30 minutos

---

## PASSO 1 — GitHub (5 min)

1. Acesse: https://github.com → "Sign up" (gratuito)
2. Crie repositório: "ironlabs-cloud" (privado)
3. Faça upload de todos os arquivos desta pasta

---

## PASSO 2 — Supabase (10 min)

1. Acesse: https://supabase.com → "Start your project"
2. Crie projeto: "ironlabs"
3. Aguarde iniciar (~2 min)
4. Vá em: **SQL Editor** → cole o conteúdo de `SUPABASE_SETUP.sql` → Execute
5. Vá em: **Settings > API** e copie:
   - **Project URL**: `https://xxxxx.supabase.co`
   - **anon public**: chave pública
   - **service_role**: chave privada (guarde com cuidado)

---

## PASSO 3 — Vercel (10 min)

1. Acesse: https://vercel.com → "Sign up with GitHub"
2. "Add New Project" → selecione `ironlabs-cloud`
3. Configure as **Environment Variables**:

```
VITE_SUPABASE_URL         → sua Project URL do Supabase
VITE_SUPABASE_ANON_KEY    → sua anon public key
SUPABASE_URL              → mesma Project URL
SUPABASE_SERVICE_KEY      → sua service_role key
ANTHROPIC_API_KEY         → sua chave Claude API
```

4. Clique "Deploy" → aguarda ~2 min
5. Sua URL será algo como: `ironlabs-cloud.vercel.app`

---

## PASSO 4 — Chave Claude API (5 min)

1. Acesse: https://console.anthropic.com
2. "API Keys" → "Create Key"
3. Copie e cole em `ANTHROPIC_API_KEY` no Vercel

---

## PASSO 5 — PWA no iPhone (2 min)

1. Abra `ironlabs-cloud.vercel.app` no Safari
2. Toque no botão de compartilhar (ícone de seta)
3. "Adicionar à Tela de Início"
4. Nomeie "Iron Labs"
5. Pronto — aparece como app na tela!

---

## ✅ VERIFICAÇÃO FINAL

Após deploy, teste:
- [ ] Abrir a URL e o sistema carrega
- [ ] Cadastrar uma venda de teste
- [ ] Verificar no Supabase → Table Editor → vendas (deve aparecer)
- [ ] Testar diagnóstico CDO
- [ ] Instalar como PWA no iPhone

---

## 🆘 SUPORTE

Se travar em qualquer passo, me manda print
que corrijo imediatamente.

---

## 💰 CUSTOS MENSAIS ESTIMADOS

| Serviço | Plano | Custo |
|---------|-------|-------|
| Vercel | Hobby (grátis) | R$0 |
| Supabase | Free (até 500MB) | R$0 |
| Claude API | ~500 análises/mês | ~R$15 |
| **TOTAL** | | **~R$15/mês** |

