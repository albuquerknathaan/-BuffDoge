# Iron Labs Pharmaceutical — Cloud System

Stack: React (Vercel) + Node.js API (Vercel Serverless) + Supabase (PostgreSQL) + Claude API
