// ══════════════════════════════════════════════════════════════════
//  IRON LABS — Cliente da API (frontend → backend)
//  Quando em desenvolvimento: usa localStorage
//  Quando em produção: usa /api/* (Vercel Serverless)
// ══════════════════════════════════════════════════════════════════

const IS_PROD = import.meta.env.PROD
const API_BASE = IS_PROD ? '' : 'http://localhost:3000'

// ── CDO AGENT ─────────────────────────────────────────────────────
export async function cdoAnalise(modo, dados) {
  if (!IS_PROD) {
    // Em dev: retorna mensagem simulada
    return `[DEV] CDO simulado — modo: ${modo}. Em produção conecta ao Claude API.`
  }
  const res = await fetch(`${API_BASE}/api/cdo`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ modo, dados })
  })
  if (!res.ok) throw new Error(`CDO API error: ${res.status}`)
  const data = await res.json()
  return data.texto
}

// ── VENDAS ─────────────────────────────────────────────────────────
export async function apiCarregarVendas() {
  if (!IS_PROD) return JSON.parse(localStorage.getItem('ironlabs_sales_v1') || '[]')
  const res = await fetch(`${API_BASE}/api/vendas`)
  if (!res.ok) throw new Error('Erro ao carregar vendas')
  return res.json()
}

export async function apiSalvarVenda(venda) {
  if (!IS_PROD) {
    const lista = JSON.parse(localStorage.getItem('ironlabs_sales_v1') || '[]')
    const nova = { ...venda, id: Date.now().toString() }
    localStorage.setItem('ironlabs_sales_v1', JSON.stringify([nova, ...lista]))
    return nova
  }
  const res = await fetch(`${API_BASE}/api/vendas`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(venda)
  })
  if (!res.ok) throw new Error('Erro ao salvar venda')
  return res.json()
}

export async function apiAtualizarStatus(id, status) {
  if (!IS_PROD) {
    const lista = JSON.parse(localStorage.getItem('ironlabs_sales_v1') || '[]')
    const atualizada = lista.map(v => v.id === id ? { ...v, status } : v)
    localStorage.setItem('ironlabs_sales_v1', JSON.stringify(atualizada))
    return
  }
  await fetch(`${API_BASE}/api/vendas`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id, status })
  })
}

export async function apiExcluirVenda(id) {
  if (!IS_PROD) {
    const lista = JSON.parse(localStorage.getItem('ironlabs_sales_v1') || '[]')
    localStorage.setItem('ironlabs_sales_v1', JSON.stringify(lista.filter(v => v.id !== id)))
    return
  }
  await fetch(`${API_BASE}/api/vendas?id=${id}`, { method: 'DELETE' })
}
