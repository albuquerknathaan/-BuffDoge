import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY)

// ── VENDAS ────────────────────────────────────────────
export async function salvarVenda(venda) {
  const { data, error } = await supabase
    .from('vendas')
    .insert([venda])
    .select()
  if (error) throw error
  return data[0]
}

export async function carregarVendas() {
  const { data, error } = await supabase
    .from('vendas')
    .select('*')
    .order('created_at', { ascending: false })
  if (error) throw error
  return data || []
}

export async function atualizarVenda(id, updates) {
  const { error } = await supabase
    .from('vendas')
    .update(updates)
    .eq('id', id)
  if (error) throw error
}

export async function excluirVenda(id) {
  const { error } = await supabase
    .from('vendas')
    .delete()
    .eq('id', id)
  if (error) throw error
}

// ── CLIENTES ──────────────────────────────────────────
export async function carregarClientes() {
  const { data, error } = await supabase
    .from('clientes')
    .select('*')
    .order('total_lucro', { ascending: false })
  if (error) throw error
  return data || []
}

export async function upsertCliente(cliente) {
  const { error } = await supabase
    .from('clientes')
    .upsert(cliente, { onConflict: 'nome' })
  if (error) throw error
}

// ── ESTOQUE ───────────────────────────────────────────
export async function carregarEstoque() {
  const { data, error } = await supabase
    .from('estoque')
    .select('*')
  if (error) throw error
  return data || []
}

export async function atualizarEstoque(codigo, quantidade) {
  const { error } = await supabase
    .from('estoque')
    .upsert({ codigo, quantidade }, { onConflict: 'codigo' })
  if (error) throw error
}

// ── INSIGHTS CDO ──────────────────────────────────────
export async function salvarInsight(insight) {
  const { error } = await supabase
    .from('insights')
    .insert([insight])
  if (error) console.warn('Insight save error:', error)
}

export async function carregarInsights(limite = 20) {
  const { data, error } = await supabase
    .from('insights')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limite)
  if (error) throw error
  return data || []
}
