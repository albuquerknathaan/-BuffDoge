-- ══════════════════════════════════════════════════════════════════
--  IRON LABS — Setup do Banco de Dados (Supabase)
--  Cole e execute no SQL Editor do Supabase
-- ══════════════════════════════════════════════════════════════════

-- 1. VENDAS
create table if not exists vendas (
  id          uuid primary key default gen_random_uuid(),
  num         text not null,
  cliente     text not null,
  telefone    text,
  produto     text not null,
  qtd         integer not null default 0,
  itens       jsonb,
  valor_total numeric(10,2) default 0,
  lucro       numeric(10,2) default 0,
  margem      numeric(5,2) default 0,
  pagamento   text default 'PIX',
  status      text default 'Pago',
  obs         text,
  data        text not null,
  created_at  timestamptz default now()
);

-- 2. CLIENTES
create table if not exists clientes (
  id            uuid primary key default gen_random_uuid(),
  nome          text unique not null,
  telefone      text,
  total_compras integer default 0,
  total_lucro   numeric(10,2) default 0,
  total_receita numeric(10,2) default 0,
  ultima_compra text,
  segmento      text default 'Regular',
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- 3. ESTOQUE (mínimos por produto)
create table if not exists estoque (
  id           uuid primary key default gen_random_uuid(),
  codigo       text unique not null,
  nome         text,
  minimo       integer default 0,
  updated_at   timestamptz default now()
);

-- 4. INSIGHTS CDO (log do agente)
create table if not exists insights (
  id         uuid primary key default gen_random_uuid(),
  modo       text not null,
  input      text,
  output     text,
  created_at timestamptz default now()
);

-- 5. META DE FATURAMENTO
create table if not exists metas (
  id         uuid primary key default gen_random_uuid(),
  mensal     numeric(10,2) default 0,
  updated_at timestamptz default now()
);
insert into metas (mensal) values (0) on conflict do nothing;

-- 6. FOLLOW-UPS
create table if not exists followups (
  id         uuid primary key default gen_random_uuid(),
  cliente    text not null,
  telefone   text,
  data       text not null,
  obs        text,
  feito      boolean default false,
  created_at timestamptz default now()
);

-- 7. FUNÇÃO: upsert cliente automático após venda
create or replace function upsert_cliente(
  p_nome     text,
  p_telefone text,
  p_lucro    numeric,
  p_receita  numeric,
  p_data     text
) returns void as $$
begin
  insert into clientes (nome, telefone, total_compras, total_lucro, total_receita, ultima_compra)
  values (p_nome, p_telefone, 1, p_lucro, p_receita, p_data)
  on conflict (nome) do update set
    telefone      = coalesce(nullif(p_telefone,''), clientes.telefone),
    total_compras = clientes.total_compras + 1,
    total_lucro   = clientes.total_lucro + p_lucro,
    total_receita = clientes.total_receita + p_receita,
    ultima_compra = p_data,
    updated_at    = now();
end;
$$ language plpgsql;

-- 8. Row Level Security (leitura pública para o app)
alter table vendas   enable row level security;
alter table clientes enable row level security;
alter table estoque  enable row level security;
alter table insights enable row level security;
alter table metas    enable row level security;
alter table followups enable row level security;

-- Permite leitura/escrita para usuários autenticados e anon (simplificado para uso pessoal)
create policy "Allow all" on vendas    for all using (true) with check (true);
create policy "Allow all" on clientes  for all using (true) with check (true);
create policy "Allow all" on estoque   for all using (true) with check (true);
create policy "Allow all" on insights  for all using (true) with check (true);
create policy "Allow all" on metas     for all using (true) with check (true);
create policy "Allow all" on followups for all using (true) with check (true);

-- 9. Índices para performance
create index if not exists idx_vendas_cliente  on vendas(cliente);
create index if not exists idx_vendas_data     on vendas(data);
create index if not exists idx_vendas_created  on vendas(created_at);
create index if not exists idx_clientes_lucro  on clientes(total_lucro desc);
create index if not exists idx_insights_created on insights(created_at desc);

select 'Setup concluído! Tabelas criadas.' as resultado;
